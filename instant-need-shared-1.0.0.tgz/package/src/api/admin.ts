import apiClient from "./client";
import type {
  AdminCustomerSummary,
  AdminCustomerDetail,
  UpdateCustomerStatusRequest,
  UpdateCustomerRoleRequest,
  DashboardSummary,
  SalesReportResponse,
  TopProductEntry,
  CustomerActivityEntry,
  AdminAuditLogEntry,
} from "../types/admin";
import type { PagedResponse } from "../types/common";
import type { AddressDTO } from "../types/customer";

export const adminCustomerApi = {
  getCustomers: (params?: { search?: string; page?: number; size?: number }) =>
    apiClient
      .get<PagedResponse<AdminCustomerSummary>>("/admin/customers", { params })
      .then((r) => r.data),

  getCustomer: (id: string) =>
    apiClient.get<AdminCustomerDetail>(`/admin/customers/${id}`).then((r) => r.data),

  updateStatus: (id: string, body: UpdateCustomerStatusRequest) =>
    apiClient.patch<AdminCustomerSummary>(`/admin/customers/${id}/status`, body).then((r) => r.data),

  updateRole: (id: string, body: UpdateCustomerRoleRequest) =>
    apiClient.patch<AdminCustomerSummary>(`/admin/customers/${id}/role`, body).then((r) => r.data),

  getCustomerAddresses: (id: string) =>
    apiClient.get<AddressDTO[]>(`/admin/customers/${id}/addresses`).then((r) => r.data),
};

export const adminReportsApi = {
  getDashboardSummary: () =>
    apiClient.get<DashboardSummary>("/admin/reports/summary").then((r) => r.data),

  getSalesReport: (params?: { from?: string; to?: string }) =>
    apiClient.get<SalesReportResponse>("/admin/reports/sales", { params }).then((r) => r.data),

  getTopProducts: (params?: { limit?: number; from?: string; to?: string }) =>
    apiClient.get<TopProductEntry[]>("/admin/reports/top-products", { params }).then((r) => r.data),

  getCustomerActivity: (params?: { limit?: number }) =>
    apiClient
      .get<CustomerActivityEntry[]>("/admin/reports/customer-activity", { params })
      .then((r) => r.data),
};

export const adminAuditApi = {
  getLogs: (params?: {
    entityType?: string;
    actionType?: string;
    page?: number;
    size?: number;
  }) =>
    apiClient
      .get<PagedResponse<AdminAuditLogEntry>>("/admin/audit-logs", { params })
      .then((r) => r.data),
};
