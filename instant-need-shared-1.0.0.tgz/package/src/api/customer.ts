import apiClient from "./client";
import type { CustomerProfileDTO, UpdateProfileRequest, AddressDTO, CreateAddressRequest } from "../types/customer";

export const customerApi = {
  getProfile: () =>
    apiClient.get<CustomerProfileDTO>("/me").then((r) => r.data),

  updateProfile: (body: UpdateProfileRequest) =>
    apiClient.patch<CustomerProfileDTO>("/me", body).then((r) => r.data),

  getAddresses: () =>
    apiClient.get<AddressDTO[]>("/me/addresses").then((r) => r.data),

  createAddress: (body: CreateAddressRequest) =>
    apiClient.post<AddressDTO>("/me/addresses", body).then((r) => r.data),

  updateAddress: (id: string, body: Partial<CreateAddressRequest>) =>
    apiClient.patch<AddressDTO>(`/me/addresses/${id}`, body).then((r) => r.data),

  deleteAddress: (id: string) =>
    apiClient.delete<void>(`/me/addresses/${id}`).then((r) => r.data),

  setDefaultAddress: (id: string) =>
    apiClient.patch<AddressDTO>(`/me/addresses/${id}/default`).then((r) => r.data),

  savePushToken: (token: string) =>
    apiClient.put<void>("/me/push-token", { token }).then((r) => r.data),
};
