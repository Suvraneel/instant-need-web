import apiClient from "./client";
import type { CartDTO, AddToCartRequest, UpdateCartItemRequest } from "../types/cart";

export const cartApi = {
  getCart: () =>
    apiClient.get<CartDTO>("/cart").then((r) => r.data),

  addItem: (body: AddToCartRequest) =>
    apiClient.post<CartDTO>("/cart/items", body).then((r) => r.data),

  updateItem: (itemId: string, body: UpdateCartItemRequest) =>
    apiClient.patch<CartDTO>(`/cart/items/${itemId}`, body).then((r) => r.data),

  removeItem: (itemId: string) =>
    apiClient.delete<CartDTO>(`/cart/items/${itemId}`).then((r) => r.data),

  clearCart: () =>
    apiClient.delete<void>("/cart").then((r) => r.data),
};
