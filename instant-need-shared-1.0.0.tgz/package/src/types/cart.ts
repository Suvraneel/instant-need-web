export interface CartItemDTO {
  itemId: string;        // backend field name
  productId: string;
  productName: string;
  sku: string;
  unitOfMeasurement?: string;
  quantity: number;
  stock?: number;
  appliedUnitPrice: number; // backend field name
  lineTotal: number;
  currencyCode: string;
}

export interface CartDTO {
  cartId: string | null;  // null when no active cart yet
  status: string;
  items: CartItemDTO[];
  grandTotal: number;     // backend field name
  currencyCode: string | null;
}

export interface AddToCartRequest {
  productId: string;
  quantity: number;
}

export interface UpdateCartItemRequest {
  quantity: number;
}
