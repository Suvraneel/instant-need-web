export interface AdminCustomerSummary {
  id: string;
  fullName: string;
  businessName?: string;
  email: string;
  phoneNumber?: string;
  active: boolean;
  orderCount?: number;
  createdAt: string;
}

export interface AdminCustomerDetail extends AdminCustomerSummary {
  gstVatNumber?: string;
  notes?: string;
  defaultShippingAddressId?: string;
  addresses?: import("./customer").AddressDTO[];
  recentOrders?: unknown[];
  orders?: unknown[];
  orderCount?: number;
  totalRevenue?: number;
}

export interface UpdateCustomerStatusRequest {
  active: boolean;
}

export interface UpdateCustomerRoleRequest {
  role: "CUSTOMER" | "ADMIN";
}

export interface DashboardSummary {
  totalRevenue?: number;
  totalOrders?: number;
  ordersByStatus?: Record<string, number>;
  totalCustomers?: number;
  totalProducts?: number;
  pendingOrders?: number;
  processingOrders?: number;
  shippedOrders?: number;
  revenueThisMonth?: number;
  newCustomersThisMonth?: number;
  activeProducts?: number;
}

export interface SalesBreakdownEntry {
  date: string;
  orderCount: number;
  revenue: number;
}

export interface SalesReportResponse {
  totalOrders: number;
  totalRevenue: number;
  averageOrderValue?: number;
  breakdown: SalesBreakdownEntry[];
}

export interface TopProductEntry {
  productId: string;
  productName: string;
  sku?: string;
  currencyCode?: string;
  totalQuantity?: number;
  unitsSold?: number;
  totalRevenue: number;
}

export interface CustomerActivityEntry {
  customerId: string;
  fullName?: string;
  customerName?: string;
  businessName?: string;
  email?: string;
  orderCount: number;
  totalRevenue: number;
  lastOrderAt?: string;
}

export interface AdminAuditLogEntry {
  id: string;
  adminUserId: string;
  adminEmail?: string;
  entityType: string;
  actionType: string;
  entityId: string;
  changesSummary?: string;
  createdAt: string;
}
